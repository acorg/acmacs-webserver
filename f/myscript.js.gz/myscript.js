console.log('myscript.js is here');

/*
if you’re trying to use libwebsockets you probably want to build your own awesome WebSocket server.
I’ve already made a tutorial on how to make a web server using libwebsocket and finally now I’m going to make a very simple WebSocket server. At first, I wanted to make just a “port” of my previous tutorial on Node.js but this would be I think much more complicated and I wanted to keep this as simple as possible.
But still I recommend you to read the first tutorial about building a web server because there are some insight of how does libwebsocket work and it’ll be easier to understand what’s going on here.
BTW, if you’re looking for some more in-depth information on how WebSockets work I recommend this article Websockets 101.
So, to keep it very simple our WebSocket server will just respond to every request you send it reverse order. For example if we send “Hello, world!” it will respond “!dlrow ,olleH”.

Hiawatha is a lightweight, open source web server with a focus geared
toward security and ease of use. This particular light weight server
isn’t designed for embedded systems, but as a fully-functioning,
dynamic web server. Some of the features of this particular server
include: load balancing, FastCGI, large file support, reverse proxy,
chroot support, rewrite support, SSL/TLS, basie/digest HTTP
authentication, IPv6 support, virtual hosting, and much more.

But what about the security? Via built-in technology, Hiawatha can
stop SQL injections, XSS and CSRF attacks, control external image
linking, ban potential hackers and limit the runtime of CGI
applications and exploit attempts. There is also a built-in monitoring
tool that allows you to keep tabs on all of your web servers.

Even with this solid feature set, Hiawatha remains an ideal option for
embedded systems ─ especially those that require added security.

Who is Hiawatha right for? If you’re looking for a robust web server
for either a standard setup or embedded system, and require a higher
level of built-in security, Hiawatha is the server for you.

When deciding on a web server, it’s very tempting to go with the most
widely used system on the planet ─ Apache. But when you have a need
that Apache can’t fill, it’s good to know there are alternatives
available. Be it for an embedded system, a standard server, or a test
environment, open source has your web server needs covered. Give one
of these systems a try and see if they don’t meet or exceed your
expectations.
*/
