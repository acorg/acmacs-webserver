window.onload = function()
{
    console.log('myscript.js is here', window.location.href);
    console.log('ARGV', window.ARGV);

    var host_port = window.location.href.match(/https?:\/\/([^\/]+)/i)[1];

    var ws = new WebSocket("wss://" + host_port + "/myws", "protocolOne");
    var messages = 0;
    ws.onmessage = function (event) {
        console.log("WS MSG " + messages, event.data);
        ++messages;
        if (messages === 1) {
            ws.send("first-message: " + host_port);
        }
        else {
            ws.close();
        }
    };

    ws.onclose = function (event) {
        console.log("WS CLOSED by server, code: " + event.code + " reason: " + event.reason);
    };
}
