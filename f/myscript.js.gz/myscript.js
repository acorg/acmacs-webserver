console.log('myscript.js is here');

var ws = new WebSocket("wss://localhost:3000/", "protocolOne");
var messages = 0;
ws.onmessage = function (event) {
    console.log("WS MSG " + messages, event.data);
    ++messages;
    if (messages === 1) {
        ws.send("first-message");
    }
    else {
        ws.close();
    }
}
